import React from 'react';

const Experience = () => {
    return (
        <div className="experience">
            <h3>Experience</h3>
            <div className="exp-1">
                <h4>Administrateur System et reseaux -Hypparcos technologie</h4>
                <h5>2009-2010</h5>
                <p> Administrateur d'un serveur SBS 2008 serveur</p>
            </div>
            <div className="exp-2">
                <h4>Administrateur System et reseaux -Hypparcos technologie</h4>
                <h5>2009-2010</h5>
                <p> Administrateur d'un serveur SBS 2008 serveur</p>
            </div>
        </div>
    );
};

export default Experience;