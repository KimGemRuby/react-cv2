import React from 'react';
import Navigation from '../components/Navigation';

const Portfolio = () => {
    return (
        <div>
            <Navigation />
            Portfolio
        </div>
    );
};

export default Portfolio;